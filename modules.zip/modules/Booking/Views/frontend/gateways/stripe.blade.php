<div class="card_stripe">
    <input name="bravo_stripe_token" type="hidden" value="" id="bravo_stripe_token"/>
</div>
