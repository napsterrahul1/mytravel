@extends('Email::layout')
@section('content')
    <div class="b-container">
        <div class="b-panel">
            {!! $content !!}
        </div>
    </div>
@endsection
